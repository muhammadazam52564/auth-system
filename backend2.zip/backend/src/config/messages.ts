const messages = {
    UNKNOWN_ERROR: "Something went wrong please try again",
    USER_CREATED : "User created successfully!",
    INVALID_CREDENTIALS: "username or password incorrect",
    LOGIN_SUCCESS: "login successful",
    EMAIL_TAKEN: "Email already exisit",
    UNAUTHORIZED_REQUEST: "Unauthrized request",
    SUCCESS: "Profile Data Successful"
}

module.exports = messages

